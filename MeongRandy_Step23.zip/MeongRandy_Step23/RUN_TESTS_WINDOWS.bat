@echo off
setlocal
cd /d "%~dp0"
set "GODOT=%~1"
if "%GODOT%"=="" set "GODOT=godot"
for %%T in (check_units check_skills check_fusion check_all check_beasts check_beast_recipes check_gacha check_draw_ui check_mythics check_mythic_recipes check_mythic_gacha check_transcendents check_transcendent_recipes check_transcendent_gacha check_difficulty check_wave_stats check_regular_waves check_boss_rounds check_game_speed check_matchups check_balance check_economy check_integration_step22 check_step23_ui check_step23_layout check_step23_sell check_step23_effects_chat check_step23_popup_full_height check_step23_draw_button_alignment check_step23_popup_content_spacing check_step23_recipe_button_alignment check_step23_field_limit check_step23_auto_rounds check_step23_hud_text_fit) do (
  echo ===== %%T =====
  "%GODOT%" --headless --path "%CD%" --script "res://tests/%%T.gd"
  if errorlevel 1 (
    echo FAIL: %%T
    pause
    exit /b 1
  )
)
echo ALL GODOT TESTS PASSED
pause
