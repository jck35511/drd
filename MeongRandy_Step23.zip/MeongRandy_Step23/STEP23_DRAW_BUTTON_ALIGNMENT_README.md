# Step23 뽑기 정보 버튼 정렬 패치

- 맹수/신화/초월 뽑기 3개 버튼을 팝업 폭에 맞춰 동일 너비로 배치합니다.
- 보유 아이템/최근 결과/확률표 3개 탭 버튼도 동일 너비로 배치합니다.
- 각 줄은 좌우 여백 및 간격을 통일합니다.
- 뽑기 확률, 아이템, 선택 기능과 기존 UI는 변경하지 않았습니다.
- `check_step23_draw_button_alignment.gd` 검사를 배치 테스트에 추가했습니다.

Windows 전체 테스트 명령:
`RUN_TESTS_WINDOWS.bat "C:\Users\고희원\Desktop\AIStudio_v2.7.1\Godot_v4.7.2-stable_win64.exe"`
