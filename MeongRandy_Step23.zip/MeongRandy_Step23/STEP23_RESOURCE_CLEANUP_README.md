# Step23 리소스 정리 테스트 수정

- `check_step23_field_limit.gd` 및 `check_step23_auto_rounds.gd`의 게임 객체 `g`를 테스트 종료 전 `g.free()`로 정리합니다.
- 기존 테스트에서 `Game.new()`로 생성한 Control 객체가 SceneTree에 연결되지 않은 상태에서 `quit()`를 호출하여 CanvasItem RID, ObjectDB, resources still in use 경고를 남긴 것으로 추정됩니다.
- 실제 게임 로직, UI, 웨이브, 패배 조건을 변경하지 않았습니다.
- Windows에서 `RUN_TESTS_WINDOWS.bat "C:\Users\고희원\Desktop\AIStudio_v2.7.1\Godot_v4.7.2-stable_win64.exe"`로 회귀 테스트와 경고 제거를 확인해야 합니다.
