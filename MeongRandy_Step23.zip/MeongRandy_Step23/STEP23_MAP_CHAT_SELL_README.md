# Step23 — expanded battlefield, readable chat and contextual sale

- 6×6 (36 cells) retained; CELL 67 → 77 and origin (159,225) → (127,197).
- Monster rectangular clockwise route kept in shape, aligned to larger board; no combat stats modified.
- Battlefield click area ends above log, preventing accidental interception.
- Dark chat panel for status, instructions and draw odds; no overlap with bottom action dock.
- When selected, a contextual unit information strip and sale button appear between map and chat; hidden when nothing is selected.
- Sale prices remain small 10G, medium 40G, large 100G; other tiers not sellable.
- Existing UI, fusion, gacha, difficulty and restart rules unchanged.

## Required Windows verification
`RUN_TESTS_WINDOWS.bat "C:\Users\고희원\Desktop\AIStudio_v2.7.1\Godot_v4.7.2-stable_win64.exe"`

This environment cannot run that Windows executable; no Windows test pass is claimed. Review the actual game at 540×960 and confirm chat, selected-row overlap, and attack targeting.
