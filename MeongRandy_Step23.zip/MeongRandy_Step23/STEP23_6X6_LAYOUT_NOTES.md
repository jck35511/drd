# Step23 final UI layout (6×6 unchanged)

Source: MeongRandy_Step23_Popup_Layout_Fix.zip

Changes scoped to `main.gd` presentation/geometry:
- Compact top HUD: life / gold / wave + difficulty / speed / settings. Star counter hidden in UI only.
- First dock row: summon / start wave / crafting mission. Restart stays inside Settings.
- 6×6 tiles unchanged. CELL 76→67 and GRID_ORIGIN (132,345)→(159,370) to widen surrounding lane; board decoration aligned to tile boundaries.
- Enemy ROUTE, movement speed, wave logic, attack statistics, crafting recipes and other functionality untouched.
- All dog sprites and input coordinates follow the existing cell coordinate functions.

Note: Godot executable is not installed in this runtime; static integrity checks performed, but actual runtime/gameplay validation requires Godot 4.7.2 on Windows.
