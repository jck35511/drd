MeongRandy Step7 - Beast exclusive item recipes

Beast crafting: 3 specific large dogs + 1 exclusive beast item.
Lion: 황금 사자의 문장
Tiger: 맹호의 송곳니
Wolf: 달빛 늑대의 인장
Jaguar: 그림자 재규어의 발톱
Leopard: 질풍 표범의 휘장
Fox: 신비한 여우 구슬

The draw/gacha system is NOT implemented. Each item starts at 0, so beasts cannot be crafted through normal gameplay yet. Future draws should increase game.beast_items[result_kind] and refresh the catalog. Item is consumed only on successful crafting.

No changes to existing dog names, stats, skills, summon rate or normal 26 recipes.

Run: RUN_TESTS_WINDOWS.bat "FULL_PATH_TO_GODOT_EXE"
Tests included, but not executed in this environment.
