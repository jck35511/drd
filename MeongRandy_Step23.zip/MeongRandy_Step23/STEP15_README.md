# MeongRandy Step15 — 일반 웨이브 능력치 성장

기준: 실제 Windows Godot 전체 테스트를 통과한 `MeongRandy_Step14_Fixed_v2`.

## 적용 내용
- **일반 웨이브 1~80** 기본 체력: `100 × 1.055^(wave−1)`.
- 기본 방어력: `3 + 0.42×(wave−1) + 0.012×(wave−1)^2`.
- 기본 마법 저항력: `min(25%, 10% + floor((wave−1)/4)×1%p)`.
- 난이도별 체력·방어력 배율은 Step14 설정 그대로, 마법 저항력은 난이도별 보정 후 0~50% 제한.
- **기본 이동속도 0.105 고정**: 기존의 `0.105 + wave×0.004` 증가 제거. 둔화·기절·빙결 효과는 정상 작동.
- 80보다 큰 웨이브 인수는 안전하게 80 기준으로 계산 (보스 스케일링은 Step17에서 별도 설계).
- **주의:** 기존 웨이브 진행·소환 수는 아직 Step16 이전 동작 유지. 18마리·40초·80회 진행 및 적 유형 선택은 Step16에서 구현.
- 신규 자동 테스트 `tests/check_wave_stats.gd` 및 `RUN_TESTS_WINDOWS.bat` 연결.

테스트: `RUN_TESTS_WINDOWS.bat "C:\Users\고희원\Desktop\AIStudio_v2.7.1\Godot_v4.7.2-stable_win64.exe"`.

Godot 실제 실행은 사용자 Windows 환경에서 확인해야 합니다.
