# Step23 HUD Text Fit

- Field count card: x10, width118 (was75), label font17.
- Gold card: x134, width110.
- Wave card: x250, width258 (was286), label x257 width244, font15, vertically centered.
- Wave timing, field limits, game systems, and all other UI unchanged.
- Added check_step23_hud_text_fit.gd to RUN_TESTS_WINDOWS.bat.
- Windows regression testing must be run on Windows using the supplied batch file.
