# Step23 HUD & mobile viewport fix

- Compact top HUD: title, lives/gold/boss, independent wave card, one-line hints.
- Toolbar moved to y=185 to keep away from enemy rectangular path (y=296 ±30).
- Bottom actions now fit completely between y=1003 and y=1252 on 720×1280.
- No changes to battle, wave, crafting, gacha or enemy route coordinates.
- Added tests/check_step23_layout.gd.
- Uses existing original illustrated forest background; character graphics are Step24 work.
