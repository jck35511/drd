# 멍랜디 Step23 — 세로형 숲속 UI 적용

기준: Step22 게임 로직·6×6 격자·사각형 몬스터 순환 경로 유지.

## 변경사항
- 720×1280 세로 화면용 숲속 배경 PNG 적용, 나무색 조작 영역 및 상단 HUD 프레임 적용.
- 공통 버튼·팝업 패널 스타일을 나무·크림·황금 톤으로 교체.
- 원래 6×6 격자와 동일 좌표·크기로 잔디 타일 밝기/테두리 개선; 주변 적 이동 경로는 좌표 동일한 3중 흙길로 묘사.
- 전투 하단의 다시하기 제거, 상단 설정 버튼과 별도 설정 메뉴·초기화 확인창 추가. 초기화 시 난이도 재선택.
- 기존 소환 20G, 웨이브, 조합, 맹수/신화/초월 50G 뽑기, 도감, 미션, 배속, 스킬·보상·난이도 유지.

## 검증
Godot에서 실행 후 터치/클릭 시 설정 팝업 열림, 취소 시 진행 상태 유지, 확인 시 초기화, 격자 터치/이동, 23개 기존 자동 테스트 확인. `RUN_TESTS_WINDOWS.bat`을 사용하세요. 신규 `check_step23_ui.gd` 통합 추가.

## 범위
Step23은 기능 UI 꾸미기이며 49종 일러스트와 신규 공격 모션, 보스 아트는 Step24~26에서 별도 적용합니다. 그래픽을 아직 상용 수준으로 완성한 상태로 보지 마세요.


## Hotfix 2026-10-29
- Headless-safe PNG load via Image.load_from_file and ImageTexture.create_from_image to avoid missing imported Texture2D resource.
- Step23 check script renamed reserved `pass` parameter to `condition`.
- Requires re-running 24 Windows Godot tests.
