# Step24 PNG resource loading fix

The previous Step24 used `load(res://assets/*.png)` and headless tests emitted `No loader found for resource` on fresh extracts before the editor imported PNGs.

This patch loads images through `Image.load()` and creates `ImageTexture` directly, which does not require `.godot` import metadata. All original sprites and gameplay scripts remain intact.

Run `RUN_TESTS_WINDOWS.bat "PATH_TO_GODOT.EXE"` and ensure there are no `ERROR:` lines, not only that the last line says PASSED. Also run the project with F5 to check appearance.

Verified here: archive integrity, all 56 PNG files decode, 49 dog files and 5 enemy files present, replacement applied. Godot runtime execution not available in this environment.
