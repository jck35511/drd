# Step23 효과 정보 및 채팅창 개선

- 기존 6×6 소환판, 몬스터 경로, 스킬 능력치, 판매 가격, 하단 버튼 유지.
- 선택 유닛 정보 패널 높이를 70에서 109로 확대하고, 실제 DOG_SKILLS와 SKILL_NAMES를 연결하여 보유 효과 표시.
- 선택하지 않으면 기존처럼 선택 정보 패널과 판매 버튼 숨김.
- 안내·채팅 패널 높이를 168에서 130으로 축소하고 메시지 위치 조정.
- `RUN_TESTS_WINDOWS.bat "C:\Users\고희원\Desktop\AIStudio_v2.7.1\Godot_v4.7.2-stable_win64.exe"` 테스트 실행 필수.
- Linux 환경에는 Godot 실행 파일이 없어 Windows 전체 검증은 별도로 진행.
