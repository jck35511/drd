# Step23 Battlefield and Sales Patch

- Maintains 6x6 board, 49 kinds, all crafting/gacha/wave/range/damage values.
- Board grid origin moved from (159,370) to (159,225), while cell size is unchanged at 67.
- Clockwise route corners changed from (58,296)-(660,894) to (130,187)-(590,665), leaving ~29-38px gap from board border to the path center. Actual route and combat use the same ROUTE constant, so target range is spatially aligned.
- Board input interception ends at Y=820, and status/help/gacha text moved to Y=852/911/953 above bottom controls at 992.
- A selected ordinary dog can be sold: small 20G, medium 50G, large 100G. Crafted beast/mythic/transcendent units show '판매 불가'. No price for other tiers was authorized.
- Sale removes selected dog and awards gold; empty cell can be summoned to again.
- Every patch must run `RUN_TESTS_WINDOWS.bat "C:\Users\고희원\Desktop\AIStudio_v2.7.1\Godot_v4.7.2-stable_win64.exe"` on Windows. Not executed here because Windows Godot executable is unavailable.
