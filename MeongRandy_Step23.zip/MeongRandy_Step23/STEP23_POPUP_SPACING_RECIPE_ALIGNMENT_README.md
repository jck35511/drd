# Step23 팝업 버튼 정렬 및 본문 여백
- 조합 도감 6개 필터 버튼: 균등한 3열×2행 배열
- 뽑기 정보: 맹수/신화/초월 및 보유 아이템/최근 결과/확률표를 균등 3열 정렬
- 버튼과 본문 사이 여백: 조합 도감 12px, 뽑기 정보 14px
- 팝업 크기·게임 규칙·판매 가격 유지
- RUN_TESTS_WINDOWS.bat에 check_step23_recipe_button_alignment 추가
