# Step23 – Expanded catalogue and draw information popups

- 조합 도감 and 뽑기 정보·보유 아이템 panels begin immediately below the top HUD (y=82) instead of y=257.
- Both panels use position `(14,82)` and size `692×893`, ending at y=975 above the bottom action dock.
- Internal scroll regions grow from 410/440 to 600/620; recipe and draw functions are preserved.
- Added `check_step23_popup_full_height.gd` to the Windows batch runner.
- Not run on Windows in this environment. Run `RUN_TESTS_WINDOWS.bat "<Godot.exe path>"` to validate.
