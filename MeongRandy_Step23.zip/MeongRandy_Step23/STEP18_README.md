# MeongRandy Step18 — 배속 시스템

Step17 기반 전체 프로젝트. 1배속 → 2배속 → 3배속 → 1배속 순환 버튼을 추가했습니다.

- 게임 시작 기본 1배속, 다시하기 시 1배속 복귀
- 일반 40초, 보스 60초는 **게임 시간** 기준으로 유지
- `_process(delta)`에서 게임 시간 `game_delta = delta * game_speed`를 만들어 몬스터 출현, 라운드 타이머, 이동, 상태 이상, 유닛 쿨다운/공격에 공통 적용
- 난이도 및 웨이브별 기본 몬스터 이동속도는 Step15 설정대로 고정
- `Engine.time_scale` 전역 값은 변경하지 않음
- 기존 49종/39개 조합식/3종 독립 뽑기 및 88라운드 규칙 유지
- 신규 테스트 `tests/check_game_speed.gd`, 기존 18개 회귀검사 포함 총 19개

Windows: `RUN_TESTS_WINDOWS.bat "C:\Users\고희원\Desktop\AIStudio_v2.7.1\Godot_v4.7.2-stable_win64.exe"`

주의: 정적 점검과 ZIP 파일 검사까지 진행했습니다. 실제 Godot 헤드리스/모바일 테스트는 사용자의 Windows Godot 실행으로 확인해야 합니다.
